<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-01-28 18:15:43
         compiled from "application/views/templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:177942684854c8c242eb2b35-56601692%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '40f4a4d22076929a12ed0796429bd8abc39f2d51' => 
    array (
      0 => 'application/views/templates/footer.tpl',
      1 => 1422449012,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '177942684854c8c242eb2b35-56601692',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54c8c242ef4c58_25293015',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54c8c242ef4c58_25293015')) {function content_54c8c242ef4c58_25293015($_smarty_tpl) {?></body>
</html>
<?php }} ?>
