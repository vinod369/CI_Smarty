<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-01-28 18:15:43
         compiled from "application/views/templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:40510231854c8c0cc08ac63-21317858%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '18f7313853879b6d937d61a5c65db403b46904a4' => 
    array (
      0 => 'application/views/templates/header.tpl',
      1 => 1422449012,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '40510231854c8c0cc08ac63-21317858',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54c8c0cc0aa9f4_58165790',
  'variables' => 
  array (
    'title' => 0,
    'name' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54c8c0cc0aa9f4_58165790')) {function content_54c8c0cc0aa9f4_58165790($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en"> 
 
<head> 
	<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</title> 
	<meta http-equiv="content-type" content="application/xhtml+xml;charset=utf-8" /> 
	<style type="text/css">
	
		body {background-color: #fff; color: #000; width: 800px; font-family: 'courier', 'courier new', monotype;}
		h1, h2 {background-color: #fff; color: #999; font-family:"Times New Roman",Georgia,serif;}
		h1 {font-size: 2em;}
		h2 {font-size: 1.5em;}
		em {border: solid #000 1px; padding: 0 5px; font-style: normal;}
		.error {background-color: #ff0; color: #c00;}
		.message {background-color: #fff; color: #0c0;}
	
	</style>
</head> 
<body>
<?php }} ?>
